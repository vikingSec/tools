cd "${0%/*}"
sleep 5400
python printChecker_3.py
sleep 28800
sudo ./check3.sh

