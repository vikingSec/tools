cd "${0%/*}"
sudo python dump3.py
echo "Sleep!"
sleep 7200
sudo ./dump3.sh

