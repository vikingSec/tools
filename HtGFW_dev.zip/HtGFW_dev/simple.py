print 'Ello!'

