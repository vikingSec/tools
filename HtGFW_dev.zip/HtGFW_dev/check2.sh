cd "${0%/*}"
sleep 5400
python printChecker_2.py
sleep 28800
sudo ./check2.sh
