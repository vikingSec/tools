cd "${0%/*}"
sudo python dump.py
echo "Sleep!"
sleep 7200
sudo ./dump.sh
