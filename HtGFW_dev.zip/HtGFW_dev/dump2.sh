cd "${0%/*}"
sudo python dump2.py
echo "Sleep!"
sleep 7200
sudo ./dump.sh

