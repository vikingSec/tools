cd "${0%/*}"
sleep 5400
python printChecker_1.py
sleep 28800
sudo ./check.sh
